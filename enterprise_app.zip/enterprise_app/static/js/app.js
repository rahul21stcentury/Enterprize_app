let appState = {
    payloadData: null,
    activeDomain: null,
    activeViewTab: "Data_Product"
};

let globalNetworkInstance = null;
let treeNetworkInstance = null;

document.addEventListener("DOMContentLoaded", () => {
    initializeEventListeners();
    loadDashboardPayload();
});

function initializeEventListeners() {
    document.getElementById("toggleDataProducts").addEventListener("click", () => switchViewModeTab("Data_Product"));
    document.getElementById("togglePhysicalEntities").addEventListener("click", () => switchViewModeTab("Physical_Entities"));
}

// Utility function to split long words/underscores into multiple lines to protect perfect circular symmetry
function wrapLabelText(text) {
    if (!text) return "";
    // Replaces underscores with spaces, then wraps text roughly every 12 characters using a newline break
    let cleanText = text.replace(/_/g, " ");
    if (cleanText.length <= 12) return cleanText;
    
    let words = cleanText.split(" ");
    let lines = [];
    let currentLine = "";
    
    words.forEach(word => {
        if ((currentLine + word).length > 12) {
            if (currentLine) lines.push(currentLine.trim());
            currentLine = word + " ";
        } else {
            currentLine += word + " ";
        }
    });
    if (currentLine) lines.push(currentLine.trim());
    return lines.join("\n");
}

async function loadDashboardPayload() {
    try {
        const response = await fetch('/api/data');
        if (!response.ok) throw new Error("API stream reading failure.");
        appState.payloadData = await response.json();
        
        const domainsList = Object.keys(appState.payloadData.domains);
        if (domainsList.length > 0) {
            renderDomainControlButtons(domainsList);
            
            // Render the cross-domain map permanently on top
            renderGlobalNetworkGraph(appState.payloadData.global_graph);
            
            activateDomainScope(domainsList[0]);
        }
    } catch (err) {
        console.error(err);
        document.getElementById("overviewTextPlaceholder").innerHTML = `<span style='color:#ef4444; font-weight:bold;'>Data Loading Failure. Please check your python log console.</span>`;
    }
}

function renderDomainControlButtons(domains) {
    const container = document.getElementById("domainButtonContainer");
    if (!container) return;
    container.innerHTML = "";
    domains.forEach(domain => {
        const btn = document.createElement("button");
        btn.className = "domain-btn";
        btn.innerText = domain;
        btn.setAttribute("data-domain", domain);
        btn.addEventListener("click", () => activateDomainScope(domain));
        container.appendChild(btn);
    });
}

function activateDomainScope(domainName) {
    if (!appState.payloadData || !appState.payloadData.domains[domainName]) return;
    
    appState.activeDomain = domainName;
    document.querySelectorAll(".domain-btn").forEach(btn => {
        btn.classList.toggle("active", btn.getAttribute("data-domain") === domainName);
    });

    const domainObj = appState.payloadData.domains[domainName];
    document.getElementById("overviewTextPlaceholder").innerText = domainObj.overview || "No layout documentation available.";
    
    const subListElement = document.getElementById("subdomainList");
    subListElement.innerHTML = "";
    if (domainObj.subdomains && domainObj.subdomains.length > 0) {
        domainObj.subdomains.forEach(sub => {
            const li = document.createElement("li");
            li.innerText = sub;
            subListElement.appendChild(li);
        });
    } else {
        subListElement.innerHTML = "<span style='color:#94a3b8; font-size:0.9rem;'>No nested subdomains mapped.</span>";
    }

    refreshViewportDisplay();
    generateSubdomainTreeOnTheFly(domainName);
}

function switchViewModeTab(targetViewMode) {
    appState.activeViewTab = targetViewMode;
    document.getElementById("toggleDataProducts").classList.toggle("active", targetViewMode === "Data_Product");
    document.getElementById("togglePhysicalEntities").classList.toggle("active", targetViewMode === "Physical_Entities");
    refreshViewportDisplay();
}

function refreshViewportDisplay() {
    const renderArea = document.getElementById("dynamicViewContent");
    if (!renderArea) return;
    renderArea.innerHTML = "";
    if (!appState.activeDomain || !appState.payloadData) return;
    const activeObj = appState.payloadData.domains[appState.activeDomain];

    if (appState.activeViewTab === "Data_Product") {
        if (!activeObj.data_products || activeObj.data_products.length === 0) {
            renderArea.innerHTML = "<p style='color:#64748b; font-style:italic;'>No analytical products mapped.</p>";
            return;
        }
        activeObj.data_products.forEach(prod => {
            const card = document.createElement("div");
            card.className = "architecture-card";
            let html = `<h4>📦 Product Context: ${prod.name}</h4>`;
            html += `<div class="nested-group"><div class="nested-title">KPI Tags</div><ul class="custom-bullet-list">`;
            prod.tags.forEach(t => { html += `<li>${t}</li>`; });
            html += `</ul></div>`;
            prod.attributes.forEach(attr => {
                html += `<div class="nested-group"><div class="nested-title">Attributes Model: ${attr.source}</div><ul class="custom-bullet-list">`;
                attr.fields.forEach(f => { html += `<li>${f}</li>`; });
                html += `</ul></div>`;
            });
            card.innerHTML = html;
            renderArea.appendChild(card);
        });
    } else {
        if (!activeObj.physical_entities || activeObj.physical_entities.length === 0) {
            renderArea.innerHTML = "<p style='color:#64748b; font-style:italic;'>No database schema recorded.</p>";
            return;
        }
        activeObj.physical_entities.forEach(ent => {
            const card = document.createElement("div");
            card.className = "architecture-card";
            let html = `<h4>🗄️ Table Schema: ${ent.name}</h4>`;
            html += `<div class="nested-group"><div class="nested-title">Dataset Columns</div><ul class="custom-bullet-list">`;
            ent.columns.forEach(col => { html += `<li>${col}</li>`; });
            html += `</ul></div>`;
            card.innerHTML = html;
            renderArea.appendChild(card);
        });
    }
}

// UPPER CANVAS: Cross-Domain Map (Perfect circles with balanced text lines)
function renderGlobalNetworkGraph(graphData) {
    const container = document.getElementById("networkCanvas");
    if (!container || !graphData) return;
    
    const palette = ['#e11d48', '#ea580c', '#d97706', '#059669', '#2563eb', '#4f46e5', '#7c3aed', '#db2777'];
    
    const formattedData = {
        nodes: new vis.DataSet(graphData.nodes.map((n, index) => ({
            id: n.id,
            label: wrapLabelText(n.label), // Splits text onto multiple lines
            shape: 'circle',
            borderWidth: 2,
            widthConstraint: { minimum: 80, maximum: 80 }, // Locks a rigid uniform circular aspect ratio
            color: { 
                background: palette[index % palette.length], 
                border: '#475569', 
                highlight: { background: '#cbd5e1', border: '#0f172a' } 
            }, 
            font: { color: '#ffffff', size: 11, bold: true, face: 'sans-serif' }
        }))),
        edges: new vis.DataSet(graphData.edges.map(e => ({
            from: e.from,
            to: e.to,
            label: e.label,
            arrows: 'to', 
            color: { color: '#cbd5e1', highlight: '#475569' }, 
            font: { size: 11, color: '#475569', background: '#ffffff' }
        })))
    };
    
    if (globalNetworkInstance) globalNetworkInstance.destroy();
    
    globalNetworkInstance = new vis.Network(container, formattedData, {
        physics: { 
            solver: 'forceAtlas2Based', 
            forceAtlas2Based: { gravitationalConstant: -280, centralGravity: 0.01, springLength: 240, damping: 0.4 } 
        }
    });
    bindGraphHoverPopupCard(globalNetworkInstance);
}

// LOWER CANVAS: Local Subdomain Tree (Perfect Identical Light Blue Spheres)
function generateSubdomainTreeOnTheFly(domainKey) {
    const container = document.getElementById("treeCanvas");
    if (!container || !appState.payloadData) return;
    
    const domainObj = appState.payloadData.domains[domainKey];
    if (!domainObj || !domainObj.subdomains || domainObj.subdomains.length === 0) {
        container.innerHTML = "<div style='padding:40px; color:#94a3b8; font-style:italic; text-align:center;'>No subdomains mapped inside data.csv for this node context.</div>";
        return;
    }

    // Main parent node
    let nodesList = [{ 
        id: domainKey, 
        label: wrapLabelText(domainKey), 
        shape: 'circle',
        borderWidth: 2,
        widthConstraint: { minimum: 85, maximum: 85 }, // Forces strict circular constraints
        color: { background: '#e0f2fe', border: '#0284c7' }, 
        font: { color: '#0369a1', bold: true, face: 'sans-serif', size: 11 } 
    }];
    
    let edgesList = [];

    // Subdomain child nodes styled identically
    domainObj.subdomains.forEach(subName => {
        nodesList.push({
            id: subName,
            label: wrapLabelText(subName), // Formats layout cleanly on separate lines
            shape: 'circle',
            borderWidth: 2,
            widthConstraint: { minimum: 85, maximum: 85 }, 
            color: { background: '#e0f2fe', border: '#0284c7' }, 
            font: { color: '#0369a1', face: 'sans-serif', bold: true, size: 10 }
        });
        edgesList.push({
            from: domainKey,
            to: subName,
            arrows: 'to',
            color: { color: '#cbd5e1' }
        });
    });

    const formattedData = {
        nodes: new vis.DataSet(nodesList),
        edges: new vis.DataSet(edgesList)
    };

    if (treeNetworkInstance) treeNetworkInstance.destroy();
    
    const treeOptions = {
        layout: {
            hierarchical: { 
                enabled: true, 
                direction: 'UD', 
                sortMethod: 'directed', 
                nodeSpacing: 340,       
                levelSeparation: 150    
            }
        },
        physics: { enabled: false }
    };

    treeNetworkInstance = new vis.Network(container, formattedData, treeOptions);
    bindGraphHoverPopupCard(treeNetworkInstance);
}

function bindGraphHoverPopupCard(networkCtx) {
    const popupCard = document.getElementById("canvasPopup");
    if (!popupCard || !networkCtx) return;
    
    networkCtx.on("hoverNode", (params) => {
        popupCard.innerHTML = `<strong>Element:</strong> ${params.node}<br><span style='color:#94a3b8; font-size:11px;'>Architecture Map Object</span>`;
        popupCard.classList.remove("hidden");
    });
    networkCtx.on("blurNode", () => popupCard.classList.add("hidden"));
    networkCtx.on("mousemove", (params) => {
        if (!popupCard.classList.contains("hidden")) {
            popupCard.style.left = (params.pointer.DOM.x + 15) + "px";
            popupCard.style.top = (params.pointer.DOM.y + 15) + "px";
        }
    });
}