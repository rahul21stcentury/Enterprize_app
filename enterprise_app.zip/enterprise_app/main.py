import re
import pandas as pd
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

def robust_string_cleaner(raw_str):
    if pd.isna(raw_str) or not str(raw_str).strip():
        return []
    clean_str = str(raw_str).strip("[]{}'\" ")
    return [i.strip().strip("'\"") for i in re.split(r'[,|]', clean_str) if i.strip()]

def ultra_robust_entity_parser(raw_str):
    if pd.isna(raw_str) or not str(raw_str).strip():
        return []
    clean_str = str(raw_str).strip()
    entities = []
    entity_blocks = re.findall(r'["\']?([a-zA-Z0-9_\s]+)["\']?\s*:\s*\{([^}]+)\}', clean_str)
    
    if not entity_blocks:
        items = re.findall(r'["\']?([a-zA-Z0-9_\s\(\)]+)["\']?', clean_str)
        return [{"name": "Schema Dataset", "columns": items}] if items else []

    for ent_name, col_block in entity_blocks:
        pairs = re.findall(r'["\']?([a-zA-Z0-9_-]+)["\']?\s*:\s*["\']?([a-zA-Z0-9_-]+)["\']?', col_block)
        columns_formatted = [f"{k} ({v})" for k, v in pairs]
        entities.append({"name": ent_name.strip(), "columns": columns_formatted})
    return entities

def ultra_robust_product_parser(raw_str):
    if pd.isna(raw_str) or not str(raw_str).strip():
        return []
    clean_str = str(raw_str).strip()
    products = []
    product_blocks = re.findall(r'["\']?([a-zA-Z0-9_-]+)["\']?\s*:\s*\{([^}]+(?:\}\s*,|\s*$))', clean_str)

    for prod_name, inner_content in product_blocks:
        tags_match = re.search(r'["\']?Tags["\']?\s*:\s*[\[\{]([^\]\}]+)[\]\}]', inner_content)
        tags = [t.strip().strip('"\'') for t in tags_match.group(1).split(',')] if tags_match else []
        attr_matches = re.findall(r'["\']?([a-zA-Z0-9_-]+)["\']?\s*:\s*\[([^\]]+)\]', inner_content)
        attributes_grouped = []
        for src, fields_str in attr_matches:
            if src != "Tags":
                fields = [f.strip().strip('"\'') for f in fields_str.split(',')]
                attributes_grouped.append({"source": src.strip(), "fields": fields})
        products.append({"name": prod_name.strip(), "tags": tags, "attributes": attributes_grouped})
    return products

@app.get("/", response_class=HTMLResponse)
async def home_dashboard(request: Request):
    return templates.TemplateResponse(name="index.html", context={}, request=request)

@app.get("/api/data")
async def extract_matrix_payload():
    try:
        df_data = pd.read_csv("data.csv", sep="|")
        df_graph = pd.read_csv("graph.csv", sep="|")
        
        df_data.columns = [c.strip() for c in df_data.columns]
        df_graph.columns = [c.strip() for c in df_graph.columns]

        domains_payload = {}
        for _, row in df_data.iterrows():
            domain = str(row["Business_Domain"]).strip()
            domains_payload[domain] = {
                "overview": str(row.get("Overview", "")).strip(),
                "subdomains": robust_string_cleaner(row.get("Subdomain", "")),
                "physical_entities": ultra_robust_entity_parser(row.get("Physical_Entities", "")),
                "data_products": ultra_robust_product_parser(row.get("Data_Product", ""))
            }

        # Structure Global Inter-Entity Relations Map
        global_network = {"nodes": set(), "edges": []}
        for _, g_row in df_graph.iterrows():
            src, tgt, lbl = str(g_row["From_Node"]).strip(), str(g_row["To_Node"]).strip(), str(g_row.get("Label", ""))
            global_network["nodes"].add(src)
            global_network["nodes"].add(tgt)
            global_network["edges"].append({"from": src, "to": tgt, "label": lbl if not pd.isna(lbl) else ""})

        formatted_global_graph = {
            "nodes": [{"id": n, "label": n} for n in global_network["nodes"]],
            "edges": global_network["edges"]
        }

        return JSONResponse(content={
            "domains": domains_payload,
            "global_graph": formatted_global_graph
        })

    except Exception as e:
        return JSONResponse(status_code=500, content={"error": f"Internal Data Processing Error: {str(e)}"})